package Q1A6;

public class Person {
       final  String name;
        final  int age;
		public Person(String name, int age) {
			super();
			this.name = name;
			this.age = age;
		}
		public String getName() {
			System.out.println("Name is :"+name);
			return name;
		}
		public String setName(String name) {
			System.out.println("Name is :"+name);
			return name;
		}
		public int getAge() {
			System.out.println("Age is :"+age);
			return age;
		}
		public int setAge(int age) {
			System.out.println("Age is :"+age);
			return age;
		}
		
public static void main(String args[])
{
	Person person=new Person("Siddhant", 22);
	person.getName();
	person.getAge();
	System.out.println("we use final so values cannot be changed!!!!!!");
//	person.setAge();
//	person.setName();
}

}

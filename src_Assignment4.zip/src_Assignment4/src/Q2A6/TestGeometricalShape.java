package Q2A6;
abstract class GeometricalShape{
	final double PI=3.14;
	abstract public void area();
	abstract public void peri();
}


public class TestGeometricalShape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package Q1A5;

public class Bank {
	protected double  accountbalance;
	protected static double interest=0.10;
	public Bank(double accountbalance) {
		super();
		this.accountbalance = accountbalance;
	}

	public double getbalance(double accountbalance)
	{
		return accountbalance;
	}
	
	public double applyinterest()
	{
		return 0;
	}
	
	@Override
	public String toString() {
		return "Bank [accountbalance=" + accountbalance + "]";
	}
	
	

}

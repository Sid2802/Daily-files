package Q1A5;

public class TestBank {

	public static void main(String[] args) {
		Bank bank=new BankA(10000);
		double accountbalance=bank.applyinterest();
		System.out.print("Account balance of BankA :");
		System.out.println(accountbalance);
		
		System.out.println("=======================");
		Bank bank1=new BankB(20000);
		double accountbalance1=bank1.applyinterest();
		System.out.print("Account balance of BankB :");
		System.out.println(accountbalance1);
		
		System.out.println("=======================");
		Bank bank2=new BankC(30000);
		double accountbalance2=bank2.applyinterest();
		System.out.print("Account balance of BankC :");
		System.out.println(accountbalance2);
		
		
				
		
		

	}
}

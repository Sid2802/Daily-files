
package Q1A5;

public class BankB extends BankA
{
	public BankB(double accountbalance) {
		super(accountbalance);
	}

	public double getbalance(double accountbalance)
	{
		return accountbalance;
	}
	
	public double applyinterest()
	{
		accountbalance=(accountbalance*interest)+accountbalance;
		
		return accountbalance;
		
	}

	@Override
	public String toString() {
		return "BankB [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	

}

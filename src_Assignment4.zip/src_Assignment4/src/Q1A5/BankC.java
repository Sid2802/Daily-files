package Q1A5;

public class BankC extends BankB
{
	public BankC(double accountbalance) {
		super(accountbalance);
	}

	public double getbalance(double accountbalance)
	{
		return accountbalance;
	}
	
	public double applyinterest()
	{
		accountbalance=(accountbalance*interest)+accountbalance;
		
		return accountbalance;
		
	}
	@Override
	public String toString() {
		return "BankC [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	

}

package Q2A5;

public class AreaofRectangle 
{
	private double length;
	private double width;
	
	public AreaofRectangle(double length,double width)
	{
		this.length=length;
		this.width=width;
	}
	
	public double areaRec()
	{
		double area=length*width;
		System.out.println("Area of rectangle:"+area);
		return area;
	}
	
	public double periRec()
	{
		double peri=2*(length+width);
		System.out.println("Perimeter of rectangle:"+peri);
		return peri;
	}

}

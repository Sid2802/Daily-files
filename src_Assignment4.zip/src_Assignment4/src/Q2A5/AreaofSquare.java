package Q2A5;

public class AreaofSquare {
	protected double side;
	
	public AreaofSquare(double side)
	{
		this.side=side;
	}
	
	public double area()
	{
		double area=side*side;
		System.out.println("Area of square:"+area);
		return area;
	}
	public double peri()
	{
		double peri=4*side;
		System.out.println("Perimeter of square:"+peri);
		return peri;
	}
	
	

}

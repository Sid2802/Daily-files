package Q2A5;

import java.util.Scanner;

public class Testarea {

	public static void main(String[] args) {
		AreaofSquare areaofSquare=new AreaofSquare(5);
		areaofSquare.area();
		System.out.println("=============================");
		areaofSquare.peri();
		System.out.println("=============================");
		AreaofRectangle areaofRectangle=new AreaofRectangle(10, 5);
		areaofRectangle.areaRec();
		System.out.println("=============================");
		areaofRectangle.periRec();
	}

}

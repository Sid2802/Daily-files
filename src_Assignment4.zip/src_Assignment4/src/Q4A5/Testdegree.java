package Q4A5;

public class Testdegree  {

	public static void main(String[] args) {
		Undergraduate undergraduate=new Undergraduate();
		undergraduate.getdegree();
		
		Postgraduate postgraduate= new Postgraduate();
		postgraduate.getdegree();
		
		
		
		
		
		
		
		

	}

}

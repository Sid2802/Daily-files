package Q4A5;

public class Postgraduate extends Degree
{
	public void getdegree()
	{   super.getdegree();
		System.out.println("I am Postgraduate");
	}

}

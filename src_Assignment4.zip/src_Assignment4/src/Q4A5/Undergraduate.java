package Q4A5;

public class Undergraduate extends Degree
{
  public void getdegree()
  {
	  super.getdegree();
	  System.out.println("Iam an Undergraduate");
	  
  }
}

package Q4A5;

public class Degree {
	void getdegree()
	{
		System.out.println("I got a degree");
	}

}

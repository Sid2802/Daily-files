package Q3A5;

public class Teststudent {

	public static void main(String[] args) {
		Student[] student=new Student[10];
		student[]student=new 
	
		
		
		for(int i=0;i<student.length;i++)
		{
			System.out.println(student[i].getName()+"name is"+student[i].getAge()+"age is"+student[i].getName());
		}
		
	}

}
package userinterface;
import java.util.Scanner;
import entity.Account;
import operations.AccountOperations;
import validation.AccountValidation;

public class TestAccount {

	public static void main(String[] args) {
		
		Account account1 = new Account();
		Account account2 = new Account();
		AccountOperations accoutOperations = new AccountOperations();
		AccountValidation accountValidation=new AccountValidation();
		int ch;
		String choice;

		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("---------------");
			System.out.println("---ICIC Bank---");
			System.out.println("---------------");
			System.out.println("1.Accept Details");
			System.out.println("2.Display Details");
			System.out.println("3.Withdraw Ampount");
			System.out.println("4.Deposite Amount");
			System.out.println("5.Transfer Amount");
			System.out.println("6.Check Balance");
			System.out.println("7.Update Balance");
			System.out.println("8.Exit");

			System.out.print("Enter your choice :");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
				System.out.println("Enter accno,holdername,balance");
				int accNo=sc.nextInt();
				String accHoldername=sc.next();
				double balance=sc.nextDouble();
				boolean result=accountValidation.checkAll(accNo, accHoldername, balance);
				if(result==true)
				{
					System.out.println("all inputs are valid");
					account1.setAccno(accNo);
					account1.setAccHolderName(accHoldername);
					account1.setBalance(balance);
				}
				else
					System.out.println("invalid inpute.....");
				
				break;
			case 2:
				System.out.println("Display the details");
				System.out.println("accNo is" + account1.getAccno());
				System.out.println("name is" + account1.getAccHolderName());
				System.out.println("balance is" + account1.getBalance());
				break;
			case 3:
				System.out.println(" Enter the amount to Withdraw");
				double amount = sc.nextDouble();
				boolean result1 = accoutOperations.withdraw(account1, amount);
				if (result1 == true) {
					System.out.println("Withdraw is successful");
					System.out.println("The new balance is " + account1.getBalance());
				} else
					System.out.println("Withdraw is failed");
				break;
			case 4:
				System.out.println("Enter the amount to Deposite ");
				amount = sc.nextDouble();
				result = accoutOperations.deposite(account1, amount);
				if (result = true) {
					System.out.println("Amount deposited succesfully");
					System.out.println("The new balance is " + account1.getBalance());
				} else
					System.out.println("Deposit is failed");

				break;
			case 5:
				System.out.println("===========================");
				System.out.println("account1 old balance is"+account1.getBalance());
				System.out.println("account2 old balance is"+account2.getBalance());
				System.out.println("Enter accno,holdername,balance");
				 accNo=sc.nextInt();
				 accHoldername=sc.next();
				 balance=sc.nextDouble();
				 result=accountValidation.checkAll(accNo, accHoldername, balance);
				if(result==true)
				{
					System.out.println("all inputs are valid");
					account1.setAccno(accNo);
					account1.setAccHolderName(accHoldername);
					account1.setBalance(balance);
				}
				else
					System.out.println("invalid inpute.....");
				
			
				System.out.println("Enter the amout to Transfer");
				amount=sc.nextDouble();
				result=accoutOperations.transfer(account1, account2, amount);
				
				if(result==true)
				{
					System.out.println("Transfer is succesful....");
					System.out.println("account1 new balance is"+account1.getBalance());
					System.out.println("account2 new balance is"+account2.getBalance());
				}else
					System.out.println("Transfer is failed");
				
				break;
			case 6:
				System.out.println("the  Balance is"+account1.getBalance());
				break;
			case 7:
				System.out.println("Enter the new balance");
				balance=sc.nextDouble();
				account1.setBalance(balance);
				System.out.println("Updated balance");
				System.out.println(account1);
				break;
			case 8:
				System.out.println("Thankyou for visiting !!!!!!");
				System.exit(0);
			}
			System.out.print("Do you want to continue :");
			choice = sc.next();

		} while (choice.equalsIgnoreCase("Y"));
		System.out.println("Thankyou for visiting !!!!!!");

	}

}

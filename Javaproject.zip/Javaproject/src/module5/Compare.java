package module5;

public class Compare {

	public static void main(String[] args) {
		int a=10;
		int b=20;
		if(a==b)
		{
			System.out.println("same");
		}
		else
		{
			System.out.println("not Same");
		}
		System.out.println("--------");
		String str1="Siddhant";
		String str2="Siddhant";
		if(str1==str2)
		{
			System.out.println("same");
		}
		else
		{
			System.out.println("notSame");
		}
		System.out.println("--------");
		String str3="Siddhant";
		String str4="siddhant";
        if(str3.equals(str4))
        {
			System.out.println("same");
		}
		else
		{
			System.out.println("not Same");
		}
        System.out.println("--------");
		String str5="Siddhant";
		String str6="siddhant";
		 if(str3.equalsIgnoreCase(str4))
	        {
				System.out.println("same");
			}
			else
			{
				System.out.println("not Same");
			}
}
	
}

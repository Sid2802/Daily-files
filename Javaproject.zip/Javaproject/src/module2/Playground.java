package module2;

import java.util.Scanner;

public class Playground {
	private String name;
	private int age;
	private String gender;
	private String Location;
	private int equipmentid;
	
	Scanner sc=new Scanner(System.in);
	
	public void accept() {
		System.out.print("Enter Name :");
		name=sc.next();
		System.out.print("Enter Age :");
		age=sc.nextInt();
		System.out.print("Enter Gender :");
		gender=sc.next();
		System.out.print("Enter Location :");
		Location=sc.next();
		System.out.print("Enter Equipment id  :");
		equipmentid=sc.nextInt();
	}
	public void display() {
		System.out.println("Name"+name);
		System.out.println("Age"+age);
		System.out.println("Gender"+gender);
		System.out.println("Location"+Location);
		System.out.println("Equipment id"+equipmentid);
	}
	public void visitors_count() {
		System.out.println("Number of visitors");
	}
	public void Add_equipment() {
		System.out.println("Equipment Added");
	}
}

package module2;

public class teststudent {

	public static void main(String[] args) {
		System.out.println("Creating 1st object");
		student student=new student();
       // student.accept();
        student.display();
        student.attendClass();
        student.apperExam();
        student.completeAssignment();
        System.out.println("-------------------");
        student student1=new student();
        //student1.accept();
        student1.display();
        student1.attendClass();
        student1.apperExam();
        student1.completeAssignment();
        
        
//		System.out.println("-------------------");
//		System.out.println("Creating 2nd object");
//		student student1=new student();
//		student1.rollno=2;
//		student1.name="Sancheti";
//		student1.Score=87.2;
//		
//		System.out.println("Calling the methods");
//		student1.display();
//		student1.completeAssignment();
//		student1.attendClass();
//		student1.apperExam();
		
		
		

	}

}

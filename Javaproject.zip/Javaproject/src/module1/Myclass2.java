package module1;

public class Myclass2 {

	public static void main(String[] args) {
        int empno=01;
        String name="Siddhant";
        double sal=30000.50;
        float comm=1000.66f;
        float bonus=(float)500.5;
        byte b=100;
        short s=2000;
        long l=989898989898l;
        char gender='M';
        boolean passStatus=true;
        System.out.println("empno"+empno);
        System.out.println("Name"+name);
        System.out.println("Salary"+sal);
        System.out.println("Comm is "+comm);
        System.out.println("Bonus"+bonus);
        System.out.println("B"+b);
        System.out.println("S"+s);
        System.out.println("long"+l);
        System.out.println("Gender"+gender);
        System.out.println("Pass Status "+passStatus);
        
	}

}

package module4;

import java.util.Scanner;

public class Employee {
	private int empNo;
	private String ename;
	private double bal;
	
	Scanner sc=new Scanner(System.in);
	
	public void accept()
	{
		System.out.println("Enter name ,age ,bal");
		empNo=sc.nextInt();
		ename=sc.next();
		bal=sc.nextDouble();
	}
	
	public void empno()
	{
		if(empNo>0 && empNo<100)
		{
			System.out.println("Valid Employee Number");
		}
		else
			System.out.println("Invalid Employee Number");
	}
	
	public void checkbalance()
	{
		if(bal>0 && bal<10000) {
			System.out.println("valid bal");
	}
	else 
	{
		System.out.println("produce the proof");
	}
	}
	public void display()
	{

	}
}

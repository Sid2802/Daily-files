package module6;

public class AutoboxDemo {

	public static void main(String[] args) {
		//Conversion of primitive types to the object
		int a=10;
		Integer i=a;
         int a1=i;
         System.out.println(i);
         System.out.println("---------------------------------");
         System.out.println(a1)
         
         ;
	}

}

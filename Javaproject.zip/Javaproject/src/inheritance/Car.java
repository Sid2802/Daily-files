package inheritance;

public class Car {
	protected String companyname;
	protected String colour;
	protected String type;
	public Car(String companyname, String colour, String type) {
		super();
		this.companyname = companyname;
		this.colour = colour;
		this.type = type;
	}
	public void display()
	{
		System.out.println("Display of car class");
	}
	@Override
	public String toString() {
		return "Car [companyname=" + companyname + ", colour=" + colour + ", type=" + type + "]";
	}
	
	
	

}

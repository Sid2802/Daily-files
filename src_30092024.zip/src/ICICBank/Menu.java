package ICICBank;

import java.util.Scanner;

public class Menu {

	public static void main(String[] args) {
		int ch;
		String choice;
		
		Scanner sc=new Scanner(System.in);
		do {
			 System.out.println("---------------");
	          System.out.println("---ICIC Bank---");
	          System.out.println("---------------");
	          System.out.println("1.Accept Details");
	          System.out.println("2.Display Details");
	          System.out.println("3.Withdraw Ampount");
	          System.out.println("4.Deposite Amount");
	          System.out.println("5.Transfer Amount");
	          System.out.println("6.Check Balance");
	          System.out.println("7.Update Balance");
	          System.out.println("8.Exit");
	          
	          System.out.print("Enter your choice :");
	          ch=sc.nextInt();
	          switch(ch)
	          {
	          case 1:
	        	  System.out.println("Accept the details");
	        	  break;
	          case 2:
	        	  System.out.println("Display the details");
	        	  break;
	          case 3:
	        	  System.out.println("Withdraw Ampount");
	        	  break;
	          case 4:
	        	  System.out.println("Deposite Amount");
	        	  break;
	          case 5:
	        	  System.out.println("Transfer Amount");
	        	  break;
	          case 6:
	        	  System.out.println("Check Balance");
	        	  break;
	          case 7:
	        	  System.out.println("Update Balance");
	        	  break;
	          case 8:
	        	   System.out.println("Thankyou for visiting !!!!!!");
	        	  System.exit(0);
	          }
	          System.out.print("Do you want to continue :");
	          choice=sc.next();
	          
		}while(choice.equalsIgnoreCase("Y"));
        System.out.println("Thankyou for visiting !!!!!!");

	}

}

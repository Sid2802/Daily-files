package module6;

public class Wrapperdemo {

	public static void main(String[] args) {
		String str="100";
		String str2="200";
		String str3="100.77";
		System.out.println("total is :"+(Integer.parseInt(str)+(Integer.parseInt(str2))));
		System.out.println("---------------------------------");
		System.out.println("total is :"+(Double.parseDouble(str2)+(Double.parseDouble(str3))));
		System.out.println("---------------------------------");
		System.out.println("total :"+(Float.parseFloat(str2)+(Float.parseFloat(str3))));
		System.out.println("---------------------------------");
	    System.out.println(Byte.MAX_VALUE);
	    System.out.println("---------------------------------");
	    System.out.println(Short.MAX_VALUE);
	    System.out.println("---------------------------------");
	    System.out.println(Integer.MAX_VALUE);
	    System.out.println("---------------------------------");
	    System.out.println(Long.MAX_VALUE);
	    System.out.println("---------------------------------");
	    System.out.println(Byte.MAX_VALUE);
	    System.out.println("---------------------------------");
	    System.out.println(Byte.MIN_VALUE);
 	}

}

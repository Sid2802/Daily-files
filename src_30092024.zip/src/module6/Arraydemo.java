package module6;

import java.util.Scanner;

public class Arraydemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int[]arr=new int[5];
		System.out.print("Enter the array elements :");
		
		for(int i=0;i<arr.length;i++)
		{
			arr[i]=sc.nextInt();
		}
		//1.to display using this method
		System.out.println("------------");
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		//2.enhance for loop
		//20 33 44 55 66
		//temp:arr
		System.out.println("--------");
		for(int sid:arr)
			//   V    name of arr
		{
			System.out.println(sid);
		}
	

	}

}

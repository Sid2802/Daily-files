package module6;

public class Customer {
	private int customerid;
	private String name;
	private String mobile;
	private String address;

	public Customer() {
		customerid = 0;
		name = "";
		mobile = "";
		address = "";
	}

	public Customer(int customerid, String name, String mobile, String address) {
		super();
		this.customerid = customerid;
		this.name = name;
		this.mobile = mobile;
		this.address = address;
	}

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String toString() {
		return "Customer Id" + customerid + " and name is " + name + "and mobile no is" + mobile + "Address is"
				+ address;
	}
}

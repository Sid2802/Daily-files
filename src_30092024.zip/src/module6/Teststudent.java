package module6;

import java.util.Scanner;

public class Teststudent {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter rollNo,Name,Score");
		int rollNo=sc.nextInt();
		String name=sc.next();
		double score=sc.nextDouble();
		
		Student student = new Student();
		student.setRollNo(rollNo);
		student.setName(name);
		student.setScore(score);
		//student.display();
		System.out.println("Display the details");
		System.out.println("rollno"+student.getRollNo());
		System.out.println("name"+student.getName());
		System.out.println("Score is"+student.getScore());
		student.markattendence();

		System.out.println("---------------------------------");
		System.out.println("Creating an obj with parameters");
		Student student2 = new Student(01, "Siddhant", 95);
//		student2.display();
		student2.markattendence();
		System.out.println("---------------------------------");
		System.out.println("Change the name");
		System.out.print("Enter the new name :");
		String name1=sc.next();
		System.out.print("Enter the new rollno :");
		int rollNo1=sc.nextInt();
		System.out.print("Enter the new score :");
	    int score1=sc.nextInt();
		student2.setName(name1);
		System.out.println("New name is :"+student2.getName());
		student2.setRollNo(rollNo1);
		System.out.println("New roll no :"+student2.getRollNo());
		student2.setScore(score1);
		System.out.println("New Score is :"+student2.getScore());



	}

}

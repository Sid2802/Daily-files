package module6;

public class Testcustomer {

	public static void main(String[] args) {

		Customer customer = new Customer();

		System.out.println(customer);
//		System.out.println("Customer ID :"+customer.getCustomerid());
//		System.out.println("Name : "+customer.getName());
//		System.out.println("Mobile Number :"+customer.getMobile());
//		System.out.println("Address"+customer.getAddress());

		System.out.println("----------------------");
		System.out.println("Creating the second object");
		Customer customer1 = new Customer(2323, "Siddhant", "7066345113", "XYZ");
//		System.out.println("Customer ID :"+customer1.getCustomerid());
//		System.out.println("Name : "+customer1.getName());
//		System.out.println("Mobile Number"+customer1.getMobile());
//		System.out.println("Address"+customer1.getAddress());
		System.out.println(customer1);
	}

}

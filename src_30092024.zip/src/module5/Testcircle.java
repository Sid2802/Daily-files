package module5;

public class Testcircle {

	public static void main(String[] args) {
		Circle circle=new Circle();
		Circle circle1=new Circle();
		Circle circle2=new Circle();
		circle.accept();
		circle.calarea();
		circle.calperi();
		circle.display();
		
		System.out.println(circle.hashCode());
		System.out.println(circle1.hashCode());
		System.out.println(circle2.hashCode());
       
		//compare the objects 
		
		boolean result=circle.equals(circle1);
		System.out.println(result);
				
	}

}

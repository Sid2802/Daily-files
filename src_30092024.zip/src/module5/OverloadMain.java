package module5;

public class OverloadMain {
	public void main()
	{
	   System.out.println("main method without any parameters");
	}
	public void main(int a)
	{
	   System.out.println("main method with 1 parameters");
	}
	public void main(int a,int b)
	{
	   System.out.println("main method with 2 parameters");
	}
	public void main(int a,int b,double c)
	{
	   System.out.println("main method with 3 parameters");
	}

	public static void main(String[] args) {
		OverloadMain overloadMain=new OverloadMain();
		overloadMain.main();
		overloadMain.main(10);
		overloadMain.main(10, 20);
		overloadMain.main(10, 20, 22.40);
	}

}

package module5;

public class StaticOverloadMain {
	static public void main() {
		System.out.println("main method without any parameters");
	}

	static public void main(int a) {
		System.out.println("main method with 1 parameters");
	}

	static public void main(int a, int b) {
		System.out.println("main method with 2 parameters");
	}

	static public void main(int a, int b, double c) {
		System.out.println("main method with 3 parameters");
	}

	public static void main(String[] args) {
		main();
		main(10);
		main(10, 20);
		main(10, 20, 20.24);
	}

}

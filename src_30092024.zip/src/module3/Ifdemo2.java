package module3;

import java.util.Scanner;

public class Ifdemo2 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter Num1 :");
	int num1=sc.nextInt();
	System.out.print("Enter Num2 :");
	int num2=sc.nextInt();
	if(num1>num2)
	{
		System.out.println(num1 +"Num1 is greater");
	}
	else if(num1<num2)
	{
		System.out.println(num2 +" Num2 is greater");
	}
	else
		System.out.println("Num1 is equal Num2");
	
	}

}

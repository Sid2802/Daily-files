package module1;
import module2.Employee;
public class Testemp {
	public static void main(String args[]) {
    System.out.println("Creating object 1"); 		
	Employee employee=new Employee();
	employee.accept();
	employee.display();
	employee.completeAttendence();
	employee.completeProject();
	System.out.println("----------------------");
	System.out.println("Creating object 2");
	Employee employee1=new Employee();
	employee1.accept();
	employee1.display();
	employee1.completeAttendence();
	employee1.completeProject();

	}
}

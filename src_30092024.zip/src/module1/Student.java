package module1;

public class Student {

         private int rollno;
         private String name;
         private double Score;
         
         public void attendClass() {
        	 System.out.println("attending the class");
         }
         public void apperExam() {
        	 System.out.println("appering for exam");
         }
         public void completeAssignment() {
        	 System.out.println("complete the assignment");
         }
         
         public void display() {
        	 System.out.println("Rollno is :"+rollno);
        	 System.out.println("Name :"+name);
        	 System.out.println("Score is :"+Score);
    
         }
         public static void main(String args[]) {
        	 System.out.println("Creating a object");
        	 Student student=new Student();
        	 student.rollno=01;
        	 student.name="Siddhant";
        	 student.Score=93.27;
        	 System.out.println("Calling the member function");
        	 student.display();
        	 System.out.println("------------------------------------");
        	 System.out.println("Creating a object2");
        	 Student student2=new Student();
        	 student2.rollno=02;
        	 student2.name="Sancheti";
        	 student2.Score=83.27;
        	 System.out.println("Calling the member function");
        	 student2.display();
         }
         


	}



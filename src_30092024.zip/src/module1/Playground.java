package module1;

public class Playground {
	private String visitorsname;
	private String visitorsgender;
	private int visitorsage;
	private String location;
	private int equipmentid;
	private int visitorcount=15;
	private int visitorcheckin=11;
	private int visitorcheckout=5;	
	
	
	public void visitors_count()
	{
   	 System.out.println("Number of visitors present :"+visitorcount);
	}
	public void checkin()
	{
   	 System.out.println("Number of visitors Check in :"+ visitorcheckin);
	}
	public void checkout()
	{
   	 System.out.println("Number of visitors Check out:"+visitorcheckout);
	}
	public void display() {
   	            System.out.println("visitorsname :"+visitorsname);
   	         System.out.println("visitorsgender :"+visitorsgender);
   	      System.out.println("visitorsage :"+visitorsage);
   	     System.out.println("location :"+location);
   	     System.out.println(" equipmentid :"+ equipmentid);         
	}
	public static void main(String args[]) {
		Playground playground=new Playground();
		playground.visitorsname="Siddhant";
		playground.visitorsgender="Male";
		playground.visitorsage=23;
		playground.location="Pune";
		playground.equipmentid=23;
		playground.display();
		playground.visitors_count();
		playground.checkin();
		playground.checkout();
			
	}
	
	

}

package module1;

public class Myclass {

	public static void main(String[] args) {
	  System.out.println("Siddhant Sancheti");
	  System.out.println("CDAC");
	}

}

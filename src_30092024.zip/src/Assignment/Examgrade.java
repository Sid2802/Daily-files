package Assignment;

import java.util.Scanner;

public class Examgrade {
	private String name;
	private int sub1,sub2,sub3;
	private float average;
     Scanner sc=new Scanner(System.in);
     
     public void accept()
     {
    	System.out.println("Enter name:");
    	name=sc.next();
    	System.out.println("Enter Sub1:");
    	sub1=sc.nextInt();
    	System.out.println("Enter Sub2:");
    	sub2=sc.nextInt();
    	System.out.println("Enter Sub3:");
    	sub3=sc.nextInt();
    	
     }


}

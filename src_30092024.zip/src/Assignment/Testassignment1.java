package Assignment;

public class Testassignment1 {

	public static void main(String[] args) {
		Assignment1 assignment1=new Assignment1();
		assignment1.accept();
		assignment1.display();
		assignment1.eligibility();
		
	}

}

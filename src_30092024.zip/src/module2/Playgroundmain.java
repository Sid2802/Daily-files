package module2;

public class Playgroundmain {

	public static void main(String[] args) {
	    Playground playground=new Playground();
	    playground.display();
	    playground.accept();
	    playground.visitors_count();
	    playground.Add_equipment();

	}

}

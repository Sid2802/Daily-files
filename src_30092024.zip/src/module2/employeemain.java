package module2;

public class employeemain {

	public static void main(String[] args) {
		System.out.println("Creating 1st object");
		Employee employee=new Employee();
		employee.accept();
		employee.display();
		employee.completeAttendence();
		employee.completeProject();
		employee.applyLoan();
		System.out.println("----------------------");
		System.out.println("Creating 2st object");
		Employee employee1=new Employee();
		employee1.accept();
		employee1.display();
		employee1.completeAttendence();
		employee1.completeProject();
		employee1.applyLoan();
	}

}

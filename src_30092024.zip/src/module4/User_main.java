package module4;

public class User_main {

	public static void main(String[] args) {
		User user=new User();
		user.accept();
		user.display();
		user.checkAge();
		user.checksal();

	}

}

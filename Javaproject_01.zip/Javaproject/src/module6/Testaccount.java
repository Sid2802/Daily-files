package module6;

public class Testaccount {

	public static void main(String[] args) {
		Account account=new Account();
		account.setAccNo(2);
		account.setAccName("Sahil");
		account.setAccBalance(70000);
		System.out.println(account);
		
		System.out.println("-------------------");
		System.out.println("Creating the second object");
		Account account2=new Account(12341,"Siddhant",40000);
		System.out.println(account2);

	}

}

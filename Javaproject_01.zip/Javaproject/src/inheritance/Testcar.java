package inheritance;

public class Testcar {

	public static void main(String[] args) {
		Car car=new Car("Mustang", "Black", "Sports");
		System.out.println(car);
		System.out.println("==========");
		Petrol petrol=new Petrol("Mustang", "Black", "Sports",500,"Combustion");
        System.out.println(petrol);
        System.out.println("==========");
       
	}

}

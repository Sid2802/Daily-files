package inheritance;

public class Electric extends Petrol
{
   private int range;
   private int topspeed;
public Electric(String companyname, String colour, String type, int horsepower,String enginetype, int range,
		int topspeed) {
	super(companyname, colour, type, horsepower, enginetype);
	this.range = range;
	this.topspeed = topspeed;
}
@Override
public String toString() {
	return "Electric [range=" + range + ", topspeed=" + topspeed + ", horsepower=" + horsepower + ", enginetype="
			+ enginetype + ", companyname=" + companyname + ", colour=" + colour + ", type=" + type + "]";
}
   
}

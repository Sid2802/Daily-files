package inheritance;

public class Petrol extends Car
{
	protected int horsepower;
	protected String enginetype;
	
	public Petrol(String companyname, String colour, String type, int horsepower, String enginetype) {
		super(companyname, colour, type);
		this.horsepower = horsepower;
		this.enginetype = enginetype;
	}

	@Override
	public String toString() {
		return "Petrol [horsepower=" + horsepower + ", enginetype=" + enginetype + ", companyname=" + companyname
				+ ", colour=" + colour + ", type=" + type + "]";
	}

	
}

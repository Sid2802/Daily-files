package inheritance;

public class Testperson2 {

	public static void main(String[] args) {
		Person[] arr=new Person[5];
		arr[0]=new Person("Siddhant",22, 'M');
		arr[1]=new Person("Sahil",23, 'M');
		arr[2]=new Person("Saurabh",22, 'M');
		arr[3]=new Person("Sorabh",22, 'M');
		arr[4]=new Person("Siya",25, 'F');
		
		for(int i=0;i<arr.length;i++)
		{
			//System.out.println(arr[i]);
			System.out.println("==============================");
			System.out.println(arr[i].getName()+"is"+arr[i].getAge()+"yrs old and gender is"+arr[i].getAge());
		}

	}

}

package inheritance;

public class Testperson {

	public static void main(String[] args) {
		Person person=new Person("Siddhant", 25, 'M');
		System.out.println(person);
		person.display();
		person.fun1();
		
		System.out.println("=====================");
		Student student=new Student("Siddhant", 25, 'M', 02, "Mechanical", 82.72);
		System.out.println(student);
		
		System.out.println("=====================");
		Employee employee=new Employee("Siddhant", 25, 'M', 02, "Mechanical", 82.72, 5432,"Tata", 100000);
        System.out.println(employee);
        //binding
        System.out.println("=====================");
        Person person2=new Person("Siddhant", 22, 'M');
        System.out.println(person2);//Static binding
        System.out.println("=====================");
        person2=new Student("Siddhant", 25, 'M', 02, "Mechanical", 82.72);
        System.out.println(person2);//dynamic binding
        System.out.println("=====================");
        person2=new Employee("Siddhant", 25, 'M', 02, "Mechanical", 82.72, 5432,"Tata", 100000);
        System.out.println(person2);//dynamic binding
	}

}

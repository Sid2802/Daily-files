package module3;

public class Ordemo {

	public static void main(String[] args) {
		int a=10000;
		int b=1000;
		int c=300;
		
		if(a==b)
			System.out.println("Same");
		if(a>b || a>c)
			System.out.println("any one of the condition is true");
		if(a!=b)
			System.out.println("both are different");

	}

}

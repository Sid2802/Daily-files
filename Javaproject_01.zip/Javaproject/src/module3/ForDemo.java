package module3;

public class ForDemo {

	public static void main(String[] args) {
	      for(int i=1;i<=10;i++) {
	    	  System.out.println("Siddhant Sancheti");
	}
	 System.out.println("--------------");
	int a=1;
	while(a<=10)
	{
		 System.out.println(a);
		 a++;
	}
	
	int b=1;
	do
	{
		 System.out.println(b);
		 b++;
	}
	while(b<=10);

    }

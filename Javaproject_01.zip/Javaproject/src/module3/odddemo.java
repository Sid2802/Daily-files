package module3;

import java.util.Scanner;

public class odddemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter number :");
		int a=sc.nextInt();
	     while(a<=20){
	    	 if(a%2!=0)
	    	   {
	  	    	 System.out.println("Numer is odd ");
	  	    	 a++;
	  	     }
	     }
	  
	     

	}

}

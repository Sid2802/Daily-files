package module3;

import java.util.Scanner;

public class Switchdemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Number :");
		int num=sc.nextInt();
		switch(num)
		{
		case 5:
			System.out.println("movie time");
			break;
		case 6:
			System.out.println("Super saturday");
			break;
		case 7:
			System.out.println("Sleepy Sunday");
			break;
			default:
				System.out.println("let us complete the work");
		}

	}

}

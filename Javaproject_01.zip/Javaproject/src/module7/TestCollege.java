package module7;
class Stream{
	private String type;
	private int fees;
	private int noOfStudents;
	public Stream(String type, int fees, int noOfStudents) {
		super();
		this.type = type;
		this.fees = fees;
		this.noOfStudents = noOfStudents;
	}
	@Override
	public String toString() {
		return "stream [type=" + type + ", fees=" + fees + ", noOfStudents=" + noOfStudents + "]";
	}
	
}
class College{
	private String name;
	private char grade;
	private String address;
	private String contactNo;
	public College(String name, char grade, String address, String contactNo) {
		super();
		this.name = name;
		this.grade = grade;
		this.address = address;
		this.contactNo = contactNo;
	}
	@Override
	public String toString() {
		return "college [name=" + name + ", grade=" + grade + ", address=" + address + ", contactNo=" + contactNo + "]";
	}
	
}

public class TestCollege {

	public static void main(String[] args) {
		College college=new College("MET", 'A', "nashik", "7066345113");
		Stream stream1=new Stream("CS",100000, 120);
		Stream stream2=new Stream("IT",200000, 80);
		Stream stream3=new Stream("MEC",300000, 90);
		Stream stream4=new Stream("ELE",400000, 100);
		Stream stream5=new Stream("Civil",500000, 130);

		System.out.println(college);
		System.out.println(stream1);
		System.out.println(stream2);
		System.out.println(stream3);
		System.out.println(stream4);
		System.out.println(stream5);
	}

}

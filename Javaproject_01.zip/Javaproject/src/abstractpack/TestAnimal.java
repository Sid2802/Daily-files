package abstractpack;
abstract class Animal {
	final int legs = 4;

	abstract public void sound();

	abstract public void fun1();

	abstract public void fun2();

	public void classInfo(String type) {
		System.out.println("I belongs to " + type + "has" + legs + "legs");
	}
}

class Dog extends Animal {
	public void sound() {
		System.out.println("The dog barks");
	}

	public void fun1() {
		System.out.println("This is fun1");
	}

	public void fun2() {
		System.out.println("This is fun2");
	}
}
class Loin extends Animal {
	public void sound() {
		System.out.println("The loin roars");
	}

	public void fun1() {
		System.out.println("This is fun1");
	}

	public void fun2() {
		System.out.println("This is fun2");
	}
}
public class TestAnimal {
	public static void main(String[] args) {
		Dog tommy = new Dog();
		tommy.classInfo("Dog");
		tommy.sound();
		tommy.fun1();
		tommy.fun2();
		Loin loin = new Loin();
		loin.classInfo("loin");
		loin.sound();
		loin.fun1();
		loin.fun2();
	}

}

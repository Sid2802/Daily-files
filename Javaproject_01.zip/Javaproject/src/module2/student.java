package module2;

import java.util.Scanner;

public class student {
	Scanner sc=new Scanner(System.in);
		 private int rollno;
         private String name;
       private double Score;
        
        public void accept() {
        	System.out.print("Enter the roll number:");
        	rollno=sc.nextInt();
        	System.out.print("Enter the name :");
        	name=sc.next();
        	System.out.print("Enter the Score:");
        	Score=sc.nextDouble();
        }
        
        public void attendClass() {
       	 System.out.println("attending the class");
        }
        public void apperExam() {
       	 System.out.println("appering for exam");
        }
        public void completeAssignment() {
       	 System.out.println("complete the assignment");
        }
        
        public void display() {
       	 System.out.println("Rollno is :"+rollno);
       	 System.out.println("Name :"+name);
       	 System.out.println("Score is :"+Score);
   
        }

	}



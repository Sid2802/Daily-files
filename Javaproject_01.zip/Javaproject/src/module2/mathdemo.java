package module2;

public class mathdemo {

	public static void main(String[] args) {
		System.out.println(Math.sqrt(225));
		System.out.println(Math.abs(-225));
		System.out.println(Math.min(225,230));
		System.out.println(Math.max(225,230));
		System.out.println("No is "+Math.random());
		System.out.println("No is "+Math.random()*100);
		System.out.println("No is "+Math.random()*1000);
		System.out.println("No is "+Math.random()*10);
		double d=(int)(Math.random()*100);
		System.out.println("d is "+d);
		System.out.println(Math.round(676.99));
		System.out.println(Math.ceil(225.25));
		System.out.println(Math.floor(225.25));
		System.out.println(Math.round(948.50));
		System.out.println(Math.pow(2,3));
		

	}

}

package module2;

import java.util.Scanner;

public class Employee {
	private int empNo;
	private String name;
	private double empsalary;
	
	Scanner sc =new Scanner(System.in);
	public void accept() {
		System.out.print("Employee number :");
		empNo=sc.nextInt();
		System.out.print("Employee name :");
		name=sc.next();
		System.out.print("Employee salary :");
		empsalary=sc.nextDouble();
	}
	public void display() {
		 System.out.println("empNo :"+empNo);
       	 System.out.println("Name :"+name);
       	 System.out.println("empsalary:"+empsalary);
	}
	public void applyLoan() {
		System.out.println("Apply for loan");
	}
	public void completeProject() {
		System.out.println("Project Completed");
	}
	public void completeAttendence() {
		System.out.println("Completed Attendence");
	}
}

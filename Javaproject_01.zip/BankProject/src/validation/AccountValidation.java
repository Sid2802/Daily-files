package validation;

public class AccountValidation {
	public boolean checkaccno(int accNo) {
		if (accNo <= 0) {
			System.out.println("Invalid Account no!!!!!!!!!!!");
			return false;
		} else
			return true;
	}

	public boolean checkbalance(double balance) {
		if (balance <= 0) {
			System.out.println("invalid balance");
			return false;
		} else if (balance > 100000) {
			System.out.println("please show the proff");
			return false;
		} else
			return true;
	}

	public boolean checkaccHolderName(String accHolderName) {
		boolean valid = false;
		char ch;

		for (int i = 0; i < accHolderName.length(); i++) {
			ch = accHolderName.charAt(i);
			if ((ch >= 65 && ch <= 90) || (ch >= 97 && ch <= 122)) {
				valid = true;
			} else {
				valid = false;
				break;
			}
		}
		if (valid == true) {
			System.out.println("valid name");
			return true;
		} else {
			System.out.println("Invalid name");
			return false;
		}
	}

	public boolean checkAll(int accNo, String accHolderName, double balance) {
		if (!checkaccno(accNo))
			return false;
		if (!checkaccHolderName(accHolderName))
			return false;
		if (!checkbalance(balance))
			return false;

		else
			return true;
	}

}

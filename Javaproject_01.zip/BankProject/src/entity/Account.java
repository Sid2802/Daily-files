package entity;

public class Account {
	private int accno;
	private String accHolderName;
	private double balance;
	public Account() {
		accno=0;
		accHolderName=null;
		balance=0.0;
	}
	public Account(int accno, String accHolderName, double balance) {
		super();
		this.accno = accno;
		this.accHolderName = accHolderName;
		this.balance = balance;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAccHolderName() {
		return accHolderName;
	}
	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accno=" + accno + ", accHolderName=" + accHolderName + ", balance=" + balance + "]";
	}
	
	

}
